require("prototypes.technology")
require("prototypes.style")
require("prototypes.item")
require("prototypes.recipe")
require("prototypes.entities")

-- -- Bobs
-- if settings.startup["SpaceX-no-bob"].value == false then

-- if (not bobmods) then 
  -- bobmods = {} 
-- elseif (bobmods.lib and 
        -- bobmods.modules and 
		-- bobmods.warfare and
		-- bobmods.electronics) then
			-- require("prototypes.recipe-bobs")
			-- require("prototypes.technology-bobs")
-- end

-- end
